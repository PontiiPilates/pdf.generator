# Introduction

The body of your message.

Button Text

Thanks,<br>
<?php /**PATH C:\OSPanel\domains\pdf.generator\resources\views/email_templates/send_document.blade.php ENDPATH**/ ?>