<?php $__env->startComponent('mail::message'); ?>
# Направляем Вам Акт об оказании услуг. Просим ознакомиться и бережно хранить.

Приложения:
- Акт об оказании услуг в прикреплении

Спасибо,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\OSPanel\domains\pdf.generator\resources\views/templates/email.blade.php ENDPATH**/ ?>