<?php echo e($slot); ?>

<?php /**PATH C:\OSPanel\domains\pdf.generator\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>