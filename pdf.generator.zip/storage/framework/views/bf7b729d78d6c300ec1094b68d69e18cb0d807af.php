<!doctype html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>

    <div class="container">

        <div>
            <?php
            $services_file_logo = $names['services_file_logo'];
            $assert = asset("storage/uploads/$services_file_logo");
            ?>

            <img src="<?php echo e($assert); ?>" alt="logotip" width="300px">
        </div>

        <h6>АКТ № <?php echo e($act ?? 'Номер документа'); ?> от <?php echo e($date ?? 'Дата документа'); ?> </h6>

        <p>Исполнитель: <b>Индивидуальный предприниматель <?php echo e($name ?? 'Иллюминатов Рептилойд Степанович'); ?></b></p>

        <p>Заказчик: <b><?php echo e($name ?? 'Рога и копыта'); ?></b></p>

        <p><?php echo e($name ?? 'Наименование услуги'); ?> — <?php echo e($name ?? 'Сумма цифрами'); ?></b></p>


        <p>Общая стоимость выполненных работ, оказанных услуг: <?php echo e($name ?? 'Сумма полностью'); ?></p>

        <?php echo e($name ?? 'Почтовый адрес'); ?>


        <div class="row">

            <div class="col">
                <div class="d-flex">
                    <div class="col-2">ИНН</div>
                    <div class="col-4 ps-2 border-bottom"><?php echo e($name ?? 'ИНН'); ?></div>
                    <div class="col-2 text-center">КПП</div>
                    <div class="col-4 ps-2 border-bottom"><?php echo e($name ?? 'КПП'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Адрес</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Адрес для документов'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Р/с</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Расчетный счет'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">К/с</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Корр. счет'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Банк</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Наименование банка и города банка'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">БИК</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'БИК'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Телефон</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Телефон'); ?></div>
                </div>

                <div class="d-flex mt-3">
                    <div class="col-2 border-bottom"></div>
                    <div class="col-2"></div>
                    <div class="col-8 ps-2 border-bottom text-center"><?php echo e($name ?? 'ФИО'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2"></div>
                    <div class="col-2"></div>
                    <div class="col-8 ps-2 text-center"><small>расшифровка подписи</small></div>
                </div>
            </div>

            <div class="col">
                <div class="d-flex">
                    <div class="col-2">ИНН</div>
                    <div class="col-4 ps-2 border-bottom"><?php echo e($name ?? 'ИНН контрагента'); ?></div>
                    <div class="col-2 text-center">КПП</div>
                    <div class="col-4 ps-2 border-bottom"><?php echo e($name ?? 'КПП контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Адрес</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Адрес контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Р/с</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Расчетный счет контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">К/с</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Корр. счет контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Банк</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Наименование банка контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">БИК</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'БИК банка контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2">Телефон</div>
                    <div class="col-10 ps-2 border-bottom"><?php echo e($name ?? 'Телефон контрагента'); ?></div>
                </div>

                <div class="d-flex mt-3">
                    <div class="col-2 border-bottom"></div>
                    <div class="col-2"></div>
                    <div class="col-8 ps-2 border-bottom text-center"><?php echo e($name ?? 'ФИО контрагента'); ?></div>
                </div>
                <div class="d-flex">
                    <div class="col-2"></div>
                    <div class="col-2"></div>
                    <div class="col-8 ps-2 text-center"><small>расшифровка подписи</small></div>
                </div>
            </div>
        </div>





    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\OSPanel\domains\localhost\resources\views/pdf_templates/generate_document.blade.php ENDPATH**/ ?>